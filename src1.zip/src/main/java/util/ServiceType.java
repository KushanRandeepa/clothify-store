package util;

public enum ServiceType {
    PRODUCT,EMPLOYEE
}
