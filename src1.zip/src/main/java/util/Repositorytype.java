package util;

public enum Repositorytype {
    PRODUCT, EMPLOYEE
}
