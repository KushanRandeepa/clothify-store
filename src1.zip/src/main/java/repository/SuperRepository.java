package repository;

public interface SuperRepository {
}
